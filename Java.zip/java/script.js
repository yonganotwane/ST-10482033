let shopLocation = {
    lat: -29.8368,
    lng: 30.9913
};

let userLocation = null;

let map = L.map('map').setView([-29.8587, 31.0218], 12);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: 'OpenStreetMap'
}).addTo(map);

// Shop marker
L.marker([-29.8368, 30.9913]).addTo(map)
    .bindPopup("🚗 Wheelz for Africa")
    .openPopup();

map.on('click', function(e) {

    userLocation = e.latlng;

    L.marker([userLocation.lat, userLocation.lng]).addTo(map)
        .bindPopup("📍 Your Selected Location")
        .openPopup();

    document.getElementById("locationText").innerHTML =
        "📍 Location Selected from Map";
});

function getMyLocation() {

    if (navigator.geolocation) {

        navigator.geolocation.getCurrentPosition(function(position) {

            userLocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };

            L.marker([userLocation.lat, userLocation.lng]).addTo(map)
                .bindPopup("📍 Your Current GPS Location")
                .openPopup();

            map.setView([userLocation.lat, userLocation.lng], 14);

            document.getElementById("locationText").innerHTML =
                "📍 GPS Location Selected";

        });

    } else {
        alert("GPS not supported on this device.");
    }
}

function getDistance(lat1, lon1, lat2, lon2) {

    let R = 6371;

    let dLat = (lat2 - lat1) * Math.PI / 180;
    let dLon = (lon2 - lon1) * Math.PI / 180;

    let a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * Math.PI / 180) *
        Math.cos(lat2 * Math.PI / 180) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);

    let c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
}

function getTravelTime(distanceKm) {

    let speed = 60; // service vehicle speed

    return Math.round((distanceKm / speed) * 60);
}

let prices = {
    "Engine Repair": 1200,
    "Brake Service": 800,
    "Oil Change": 500,
    "Towing": 300
};

function calculate() {

    let condition = document.querySelector('input[name="condition"]:checked').value;
    let service = document.getElementById("service").value;

    if (!userLocation) {
        alert("Please pin your location or use GPS button.");
        return;
    }

    let distance = getDistance(
        userLocation.lat,
        userLocation.lng,
        shopLocation.lat,
        shopLocation.lng
    );

    let travelTime = getTravelTime(distance);

    let multiplier = Math.ceil(distance / 30);

    if (condition === "towing") {

        let base = 300 * multiplier;
        let total = base + (base * 0.40);

        alert(
            "🚨 TOWING REQUEST\n" +
            "Distance: " + distance.toFixed(2) + " km\n" +
            "Arrival Time: " + travelTime + " minutes\n" +
            "Total Cost: R" + total + "\n\n" +
            "Tow truck dispatched."
        );

        return;
    }

    if (condition === "immobile") {

        let timeSlot = prompt("Enter preferred service time:");

        if (!timeSlot) return;

        let callOut = prices[service] + (prices[service] * 0.30);

        alert(
            "🔧 MOBILE SERVICE\n" +
            "Distance: " + distance.toFixed(2) + " km\n" +
            "Arrival Time: " + travelTime + " minutes\n" +
            "Call-Out Fee: R" + callOut + "\n" +
            "Scheduled: " + timeSlot
        );

        return;
    }

    if (condition === "movable") {

        let time = prompt("Enter appointment time:");

        if (!time) return;

        alert(
            "✅ BOOKING CONFIRMED\n" +
            "Service: " + service + "\n" +
            "Time: " + time
        );

        return;
    }
}